# API Usage Examples

## Complete API Examples for Noryx Premium VPN

### Base URL
```
http://localhost:3000
```

---

## 1. Health Check

Check if the server is running.

### Request
```bash
curl -X GET http://localhost:3000/health
```

### Response
```json
{
  "status": "ok",
  "service": "Noryx Premium VPN"
}
```

---

## 2. Get Available Countries

Retrieve list of available VPN server locations.

### Request
```bash
curl -X GET http://localhost:3000/api/vpn/countries
```

### Response
```json
{
  "countries": [
    {
      "country_code": "auto",
      "country_name": "Auto (Best)",
      "flag_emoji": "🌍",
      "is_available": true
    },
    {
      "country_code": "us",
      "country_name": "United States",
      "flag_emoji": "🇺🇸",
      "is_available": true
    },
    {
      "country_code": "uk",
      "country_name": "United Kingdom",
      "flag_emoji": "🇬🇧",
      "is_available": true
    }
  ]
}
```

---

## 3. Smart Connect Button

The main endpoint that intelligently detects platform and returns appropriate configuration format.

### 3A. iOS Device (Deep-Link)

```bash
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15" \
  -d '{
    "userId": 1,
    "countryCode": "auto"
  }'
```

**Response:**
```json
{
  "platform": "ios",
  "deliveryFormat": "deep-link",
  "serverLocation": "United States - New York",
  "countryCode": "auto",
  "deepLink": "shadowrocket://add/ss://YWVzLTI1Ni1nY206cGFzc3dvcmQ@server.example.com:8388",
  "configUrl": "ss://YWVzLTI1Ni1nY206cGFzc3dvcmQ@server.example.com:8388"
}
```

**Usage in iOS:**
```javascript
// Click to open in Shadowrocket
window.location.href = response.deepLink;
```

---

### 3B. Android Device (Deep-Link)

```bash
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36" \
  -d '{
    "userId": 1,
    "countryCode": "us"
  }'
```

**Response:**
```json
{
  "platform": "android",
  "deliveryFormat": "deep-link",
  "serverLocation": "United States - Los Angeles",
  "countryCode": "us",
  "deepLink": "v2rayng://install-config?url=https%3A%2F%2Fapi.remnawave.com%2Fconfig%2F...",
  "configUrl": "vmess://eyJhZGQiOiJzZXJ2ZXIuZXhhbXBsZS5jb20iLCJwb3J0Ijo0NDMsImlkIjoiYWJjMTIzIn0="
}
```

**Usage in Android:**
```javascript
// Click to open in V2RayNG
window.location.href = response.deepLink;
```

---

### 3C. Windows Desktop (File Download)

```bash
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  -d '{
    "userId": 1,
    "countryCode": "uk"
  }'
```

**Response:**
```json
{
  "platform": "windows",
  "deliveryFormat": "file",
  "serverLocation": "United Kingdom - London",
  "countryCode": "uk",
  "downloadUrl": "/api/vpn/download/eyJ1c2VySWQiOjEsInN1YnNjcmlwdGlvbklkIjoic3ViX2FiYzEyMyIsImV4cGlyZXNBdCI6MTcwMDAwMDAwMCwiaG1hYyI6ImFiYzEyMy4uLiJ9",
  "expiresIn": 300
}
```

**Usage in Windows:**
```javascript
// Download configuration file
window.location.href = response.downloadUrl;
// File will download as: noryx-vpn-config.conf
```

---

### 3D. macOS Desktop (File Download)

```bash
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36" \
  -d '{
    "userId": 1,
    "countryCode": "de"
  }'
```

**Response:**
```json
{
  "platform": "macos",
  "deliveryFormat": "file",
  "serverLocation": "Germany - Frankfurt",
  "countryCode": "de",
  "downloadUrl": "/api/vpn/download/eyJ1c2VySWQiOjEsInN1YnNjcmlwdGlvbklkIjoic3ViX2RlZjQ1NiIsImV4cGlyZXNBdCI6MTcwMDAwMDAwMCwiaG1hYyI6ImRlZjQ1Ni4uLiJ9",
  "expiresIn": 300
}
```

---

### 3E. Unknown Platform (QR Code)

```bash
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: UnknownBot/1.0" \
  -d '{
    "userId": 1,
    "countryCode": "jp"
  }'
```

**Response:**
```json
{
  "platform": "unknown",
  "deliveryFormat": "qr-code",
  "serverLocation": "Japan - Tokyo",
  "countryCode": "jp",
  "qrCode": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...(base64 encoded PNG)...",
  "configUrl": "ss://YWVzLTI1Ni1nY206cGFzc3dvcmQ@japan.example.com:8388"
}
```

**Usage in HTML:**
```html
<img src="{{response.qrCode}}" alt="Scan to connect" />
```

---

## 4. Change VPN Country

Switch to a different server location without reconnecting.

### Request
```bash
curl -X POST http://localhost:3000/api/vpn/change-country \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "countryCode": "sg"
  }'
```

### Response
```json
{
  "success": true,
  "countryCode": "sg",
  "serverLocation": "Singapore - Singapore",
  "message": "VPN country changed to sg"
}
```

---

## 5. Download Configuration File

Download VPN configuration file using secure token.

### Request
```bash
# Get download URL from smart connect response
curl -X GET http://localhost:3000/api/vpn/download/eyJ1c2VySWQiOjEsInN1YnNjcmlwdGlvbklkIjoic3ViX2FiYzEyMyIsImV4cGlyZXNBdCI6MTcwMDAwMDAwMCwiaG1hYyI6ImFiYzEyMy4uLiJ9 \
  --output noryx-vpn-config.conf
```

### Response
```
# File download (application/octet-stream)
# Content-Disposition: attachment; filename="noryx-vpn-config.conf"

{
  "version": 2,
  "servers": [
    {
      "server": "us-ny-01.example.com",
      "server_port": 8388,
      "password": "encrypted_password_here",
      "method": "aes-256-gcm"
    }
  ]
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "userId is required"
}
```

### 403 Forbidden
```json
{
  "error": "No active subscription found"
}
```

### 404 Not Found
```json
{
  "error": "No active VPN configuration found"
}
```

### 500 Internal Server Error
```json
{
  "error": "Failed to connect to VPN"
}
```

---

## JavaScript Integration Examples

### Fetch API (Modern Browsers)

```javascript
// Smart Connect
async function connectVPN(userId, countryCode) {
  try {
    const response = await fetch('http://localhost:3000/api/vpn/connect', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId: userId,
        countryCode: countryCode,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error);
    }

    const data = await response.json();

    // Handle different delivery formats
    if (data.deepLink) {
      window.location.href = data.deepLink;
    } else if (data.downloadUrl) {
      window.location.href = data.downloadUrl;
    } else if (data.qrCode) {
      document.getElementById('qr-image').src = data.qrCode;
    }

    return data;
  } catch (error) {
    console.error('VPN connection failed:', error);
    throw error;
  }
}

// Get Countries
async function getCountries() {
  const response = await fetch('http://localhost:3000/api/vpn/countries');
  const data = await response.json();
  return data.countries;
}

// Change Country
async function changeCountry(userId, countryCode) {
  const response = await fetch('http://localhost:3000/api/vpn/change-country', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      userId: userId,
      countryCode: countryCode,
    }),
  });

  const data = await response.json();
  return data;
}
```

### Axios (Node.js/React)

```javascript
import axios from 'axios';

const API_BASE = 'http://localhost:3000/api/vpn';

// Smart Connect
export async function connectVPN(userId, countryCode) {
  const response = await axios.post(`${API_BASE}/connect`, {
    userId,
    countryCode,
  });
  return response.data;
}

// Get Countries
export async function getCountries() {
  const response = await axios.get(`${API_BASE}/countries`);
  return response.data.countries;
}

// Change Country
export async function changeCountry(userId, countryCode) {
  const response = await axios.post(`${API_BASE}/change-country`, {
    userId,
    countryCode,
  });
  return response.data;
}
```

---

## Testing with Different Platforms

### Test All Platforms Automatically

```bash
# Run the included test script
npm run test-api

# Or manually
./scripts/test-endpoints.sh
```

### Test Individual Platform

```bash
# iOS
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)" \
  -d '{"userId":1,"countryCode":"auto"}'

# Android
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (Linux; Android 10)" \
  -d '{"userId":1,"countryCode":"auto"}'

# Windows
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
  -d '{"userId":1,"countryCode":"auto"}'
```

---

## Rate Limiting

API is rate-limited to **100 requests per 15 minutes** per IP address.

**Rate Limit Headers:**
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-RateLimit-Reset: 1700000000
```

**Rate Limit Exceeded Response:**
```json
{
  "error": "Too many requests from this IP, please try again later."
}
```

---

## Production URLs

Replace `http://localhost:3000` with your production domain:
```
https://api.noryx.com
```

Remember to update `ALLOWED_ORIGINS` in `.env` for CORS.
