const express = require('express');
const router = express.Router();
const pool = require('../database/db');
const remnawave = require('../services/remnawave');
const { detectPlatform, getDeliveryFormat, getDeepLinkScheme } = require('../services/platformDetector');
const { generateDownloadToken, validateDownloadToken } = require('../services/tokenService');
const { generateQRCode } = require('../services/qrService');

/**
 * Smart Connect Button Endpoint
 * POST /api/vpn/connect
 *
 * Detects platform and returns appropriate configuration format:
 * - iOS: Deep-link (Shadowrocket)
 * - Android: Deep-link (V2RayNG)
 * - Desktop: Secure file download link
 * - Unknown: QR code
 */
router.post('/connect', async (req, res) => {
  try {
    const { userId, countryCode = 'auto' } = req.body;
    const userAgent = req.headers['user-agent'] || '';

    if (!userId) {
      return res.status(400).json({ error: 'userId is required' });
    }

    // Detect platform
    const platform = detectPlatform(userAgent);
    const deliveryFormat = getDeliveryFormat(platform);

    console.log(`📱 Platform detected: ${platform}, Format: ${deliveryFormat}`);

    // Check if user has active subscription
    const subscriptionQuery = await pool.query(
      `SELECT s.id, s.status, v.remnawave_subscription_id, v.country_code
       FROM subscriptions s
       LEFT JOIN vpn_configs v ON v.subscription_id = s.id
       WHERE s.user_id = $1 AND s.status = 'active' AND s.expires_at > NOW()
       ORDER BY s.created_at DESC
       LIMIT 1`,
      [userId]
    );

    let remnaSubscriptionId;
    let configUrl;
    let protocol;
    let serverLocation;

    if (subscriptionQuery.rows.length === 0) {
      return res.status(403).json({ error: 'No active subscription found' });
    }

    const subscription = subscriptionQuery.rows[0];

    // If VPN config doesn't exist or country changed, create/update
    if (!subscription.remnawave_subscription_id || subscription.country_code !== countryCode) {
      console.log('🔄 Creating new RemnaWave subscription...');

      const remnaConfig = await remnawave.createSubscription(userId, countryCode);

      remnaSubscriptionId = remnaConfig.subscriptionId;
      configUrl = remnaConfig.configUrl;
      protocol = remnaConfig.protocol;
      serverLocation = remnaConfig.serverLocation;

      // Store in database
      await pool.query(
        `INSERT INTO vpn_configs (user_id, subscription_id, remnawave_subscription_id, country_code, server_location, config_type)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (user_id, subscription_id)
         DO UPDATE SET
           remnawave_subscription_id = $3,
           country_code = $4,
           server_location = $5,
           config_type = $6,
           updated_at = CURRENT_TIMESTAMP`,
        [userId, subscription.id, remnaSubscriptionId, countryCode, serverLocation, protocol]
      );
    } else {
      console.log('✅ Using existing RemnaWave subscription...');

      remnaSubscriptionId = subscription.remnawave_subscription_id;
      const remnaConfig = await remnawave.getSubscriptionConfig(remnaSubscriptionId);
      configUrl = remnaConfig.configUrl;
      protocol = remnaConfig.protocol;
      serverLocation = remnaConfig.serverLocation;
    }

    // Log connection attempt
    await pool.query(
      `INSERT INTO connection_logs (user_id, platform, connection_type, country_code)
       VALUES ($1, $2, $3, $4)`,
      [userId, platform, deliveryFormat, countryCode]
    );

    // Return response based on delivery format
    let response = {
      platform,
      deliveryFormat,
      serverLocation,
      countryCode,
    };

    switch (deliveryFormat) {
      case 'deep-link':
        const deepLinkScheme = getDeepLinkScheme(platform, protocol);
        const deepLink = deepLinkScheme ? `${deepLinkScheme}${encodeURIComponent(configUrl)}` : configUrl;
        response.deepLink = deepLink;
        response.configUrl = configUrl;
        break;

      case 'file':
        const downloadToken = generateDownloadToken(userId, remnaSubscriptionId);
        response.downloadUrl = `/api/vpn/download/${downloadToken}`;
        response.expiresIn = 300; // 5 minutes
        break;

      case 'qr-code':
        const qrCode = await generateQRCode(configUrl);
        response.qrCode = qrCode;
        response.configUrl = configUrl;
        break;
    }

    res.json(response);

  } catch (error) {
    console.error('❌ Smart Connect error:', error.message);
    res.status(500).json({ error: 'Failed to connect to VPN' });
  }
});

/**
 * Get Available Countries
 * GET /api/vpn/countries
 */
router.get('/countries', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT country_code, country_name, flag_emoji, is_available
       FROM available_countries
       WHERE is_available = true
       ORDER BY priority DESC`
    );

    res.json({ countries: result.rows });
  } catch (error) {
    console.error('❌ Get countries error:', error.message);
    res.status(500).json({ error: 'Failed to fetch countries' });
  }
});

/**
 * Change VPN Country
 * POST /api/vpn/change-country
 */
router.post('/change-country', async (req, res) => {
  try {
    const { userId, countryCode } = req.body;

    if (!userId || !countryCode) {
      return res.status(400).json({ error: 'userId and countryCode are required' });
    }

    // Get user's current VPN config
    const configQuery = await pool.query(
      `SELECT v.remnawave_subscription_id, s.id as subscription_id
       FROM vpn_configs v
       JOIN subscriptions s ON s.id = v.subscription_id
       WHERE v.user_id = $1 AND s.status = 'active'
       ORDER BY v.created_at DESC
       LIMIT 1`,
      [userId]
    );

    if (configQuery.rows.length === 0) {
      return res.status(404).json({ error: 'No active VPN configuration found' });
    }

    const { remnawave_subscription_id, subscription_id } = configQuery.rows[0];

    // Update country in RemnaWave
    const updatedConfig = await remnawave.updateSubscriptionCountry(
      remnawave_subscription_id,
      countryCode
    );

    // Update local database
    await pool.query(
      `UPDATE vpn_configs
       SET country_code = $1, server_location = $2, updated_at = CURRENT_TIMESTAMP
       WHERE remnawave_subscription_id = $3`,
      [countryCode, updatedConfig.serverLocation, remnawave_subscription_id]
    );

    res.json({
      success: true,
      countryCode,
      serverLocation: updatedConfig.serverLocation,
      message: `VPN country changed to ${countryCode}`,
    });

  } catch (error) {
    console.error('❌ Change country error:', error.message);
    res.status(500).json({ error: 'Failed to change VPN country' });
  }
});

/**
 * Secure Config File Download
 * GET /api/vpn/download/:token
 */
router.get('/download/:token', async (req, res) => {
  try {
    const { token } = req.params;

    // Validate token
    const payload = validateDownloadToken(token);
    if (!payload) {
      return res.status(403).json({ error: 'Invalid or expired download token' });
    }

    // Get config file from RemnaWave
    const configContent = await remnawave.getConfigFileContent(payload.subscriptionId);

    // Set headers for file download
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="noryx-vpn-config.conf"`);
    res.send(configContent);

  } catch (error) {
    console.error('❌ Download error:', error.message);
    res.status(500).json({ error: 'Failed to download configuration file' });
  }
});

module.exports = router;
