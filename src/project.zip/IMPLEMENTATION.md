# Implementation Guide - Smart Connect Button

## Overview

This document explains the implementation details of the Smart Connect Button feature for Noryx Premium VPN.

## Architecture Decisions

### 1. No Traffic Proxying
The backend **does not proxy VPN traffic**. It only:
- Manages user subscriptions
- Provisions VPN configurations via RemnaWave API
- Delivers configurations in appropriate formats

### 2. PostgreSQL as Source of Truth
All user data is stored locally in PostgreSQL:
- User accounts
- Subscription status
- VPN configuration references (RemnaWave subscription IDs)
- Connection logs for analytics

### 3. Security Model

**RemnaWave Credentials**:
- Stored in environment variables server-side only
- Never exposed to client code
- Used exclusively in backend API calls

**File Downloads**:
- Protected by short-lived HMAC tokens
- Tokens expire after 5 minutes
- Token payload: `userId:subscriptionId:expiresAt:hmac`
- Cannot be forged without `HMAC_SECRET`

## Platform Detection Logic

### Detection Flow

```javascript
// src/services/platformDetector.js

function detectPlatform(userAgent) {
  if (/iPhone|iPad|iPod/i.test(userAgent)) return 'ios';
  if (/Android/i.test(userAgent)) return 'android';
  if (/Windows/i.test(userAgent)) return 'windows';
  if (/Macintosh|Mac OS X/i.test(userAgent)) return 'macos';
  if (/Linux/i.test(userAgent)) return 'linux';
  return 'unknown';
}
```

### Delivery Format Mapping

| Platform | Format | Method | Example |
|----------|--------|--------|---------|
| iOS | deep-link | URL scheme | `shadowrocket://add/ss://...` |
| Android | deep-link | URL scheme | `v2rayng://install-config?url=...` |
| Windows | file | Download | `noryx-vpn-config.conf` |
| macOS | file | Download | `noryx-vpn-config.conf` |
| Linux | file | Download | `noryx-vpn-config.conf` |
| Unknown | qr-code | Data URL | `data:image/png;base64,...` |

## Smart Connect Flow

### Step-by-Step Process

1. **Client Request**:
```javascript
POST /api/vpn/connect
{
  "userId": 1,
  "countryCode": "auto"
}
```

2. **Platform Detection**:
```javascript
const platform = detectPlatform(req.headers['user-agent']);
const deliveryFormat = getDeliveryFormat(platform);
```

3. **Subscription Check**:
```sql
SELECT s.id, s.status, v.remnawave_subscription_id
FROM subscriptions s
LEFT JOIN vpn_configs v ON v.subscription_id = s.id
WHERE s.user_id = 1 AND s.status = 'active'
```

4. **RemnaWave Provisioning** (if needed):
```javascript
if (!subscription.remnawave_subscription_id) {
  const config = await remnawave.createSubscription(userId, countryCode);
  // Store config in database
}
```

5. **Format Response**:
```javascript
switch (deliveryFormat) {
  case 'deep-link':
    return { deepLink: `scheme://add/${configUrl}` };

  case 'file':
    const token = generateDownloadToken(userId, subscriptionId);
    return { downloadUrl: `/api/vpn/download/${token}` };

  case 'qr-code':
    const qrCode = await generateQRCode(configUrl);
    return { qrCode };
}
```

## Country Selection

### Change Country Flow

1. **Client Request**:
```javascript
POST /api/vpn/change-country
{
  "userId": 1,
  "countryCode": "uk"
}
```

2. **Update RemnaWave**:
```javascript
const updated = await remnawave.updateSubscriptionCountry(
  remnawave_subscription_id,
  countryCode
);
```

3. **Update Local Database**:
```sql
UPDATE vpn_configs
SET country_code = 'uk',
    server_location = 'United Kingdom - London',
    updated_at = CURRENT_TIMESTAMP
WHERE remnawave_subscription_id = '...'
```

### Available Countries Cache

Countries are cached in `available_countries` table:
- Updated periodically from RemnaWave API
- Priority field controls display order
- `is_available` flag for temporary unavailability

## Token-Based File Downloads

### Token Generation

```javascript
function generateDownloadToken(userId, subscriptionId) {
  const expiresAt = Date.now() + 300000; // 5 minutes
  const payload = `${userId}:${subscriptionId}:${expiresAt}`;

  const hmac = crypto
    .createHmac('sha256', HMAC_SECRET)
    .update(payload)
    .digest('hex');

  const token = Buffer
    .from(`${payload}:${hmac}`)
    .toString('base64url');

  return token;
}
```

### Token Validation

```javascript
function validateDownloadToken(token) {
  const decoded = Buffer.from(token, 'base64url').toString('utf8');
  const [userId, subscriptionId, expiresAt, providedHmac] = decoded.split(':');

  // Check expiration
  if (Date.now() > parseInt(expiresAt)) return null;

  // Verify HMAC
  const payload = `${userId}:${subscriptionId}:${expiresAt}`;
  const expectedHmac = crypto
    .createHmac('sha256', HMAC_SECRET)
    .update(payload)
    .digest('hex');

  if (expectedHmac !== providedHmac) return null;

  return { userId, subscriptionId };
}
```

### Download Endpoint

```javascript
router.get('/download/:token', async (req, res) => {
  const payload = validateDownloadToken(req.params.token);
  if (!payload) return res.status(403).json({ error: 'Invalid token' });

  const configContent = await remnawave.getConfigFileContent(payload.subscriptionId);

  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', 'attachment; filename="noryx-vpn-config.conf"');
  res.send(configContent);
});
```

## QR Code Generation

Uses `qrcode` library to generate QR codes:

```javascript
const QRCode = require('qrcode');

async function generateQRCode(text) {
  return await QRCode.toDataURL(text, {
    errorCorrectionLevel: 'M',
    type: 'image/png',
    width: 300,
    margin: 2,
  });
}
```

Returns Data URL that can be embedded directly in HTML:
```html
<img src="data:image/png;base64,iVBORw0KGgoAAAA..." />
```

## RemnaWave API Integration

### Service Methods

**Create Subscription**:
```javascript
POST /subscriptions
{
  "user_id": "noryx_1",
  "country": "auto",
  "protocol": "auto"
}

Response:
{
  "subscription_id": "sub_abc123",
  "config_url": "ss://...",
  "protocol": "shadowsocks",
  "server_location": "United States - New York"
}
```

**Get Configuration**:
```javascript
GET /subscriptions/{subscription_id}

Response:
{
  "config_url": "ss://...",
  "protocol": "shadowsocks",
  "server_location": "United States - New York",
  "expires_at": "2024-12-31T23:59:59Z"
}
```

**Update Country**:
```javascript
PATCH /subscriptions/{subscription_id}
{
  "country": "uk"
}

Response:
{
  "config_url": "ss://...",
  "protocol": "shadowsocks",
  "server_location": "United Kingdom - London"
}
```

## Frontend Integration

### Smart Connect Button

```javascript
async function smartConnect() {
  const response = await fetch('/api/vpn/connect', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: USER_ID,
      countryCode: selectedCountry,
    }),
  });

  const data = await response.json();

  if (data.deepLink) {
    // iOS/Android: Open deep-link
    window.location.href = data.deepLink;
  } else if (data.downloadUrl) {
    // Desktop: Download file
    window.location.href = data.downloadUrl;
  } else if (data.qrCode) {
    // Unknown: Display QR code
    showQRCode(data.qrCode);
  }
}
```

## Error Handling

### Backend Errors

```javascript
try {
  const config = await remnawave.createSubscription(userId, countryCode);
} catch (error) {
  console.error('RemnaWave API error:', error.message);
  return res.status(500).json({
    error: 'Failed to create VPN subscription'
  });
}
```

### Frontend Errors

```javascript
try {
  const response = await fetch('/api/vpn/connect', {...});
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || 'Connection failed');
  }
} catch (error) {
  showError(error.message);
}
```

## Performance Considerations

### Database Indexes

```sql
CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_vpn_configs_remnawave_id ON vpn_configs(remnawave_subscription_id);
```

### Connection Pooling

```javascript
const pool = new Pool({
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});
```

### Rate Limiting

```javascript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per IP
});
```

## Monitoring & Analytics

### Connection Logs

```sql
INSERT INTO connection_logs
  (user_id, platform, connection_type, country_code)
VALUES
  (1, 'ios', 'deep-link', 'us');
```

Useful queries:
```sql
-- Most popular platforms
SELECT platform, COUNT(*) as connections
FROM connection_logs
GROUP BY platform
ORDER BY connections DESC;

-- Most popular countries
SELECT country_code, COUNT(*) as connections
FROM connection_logs
GROUP BY country_code
ORDER BY connections DESC;

-- Connection type distribution
SELECT connection_type, COUNT(*) as connections
FROM connection_logs
GROUP BY connection_type
ORDER BY connections DESC;
```

## Future Enhancements

1. **WebSocket Support**: Real-time connection status updates
2. **User Authentication**: JWT-based auth system
3. **Usage Analytics**: Bandwidth tracking and reporting
4. **Multi-Protocol Support**: WireGuard, OpenVPN, IKEv2
5. **Load Balancing**: Automatic server selection based on load
6. **Geo-Location**: Auto-detect user's country for better defaults
7. **Mobile Apps**: Native iOS and Android clients
8. **Admin Dashboard**: Server management and user analytics
