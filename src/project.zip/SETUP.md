# Quick Setup Guide - Noryx Premium VPN

## Step-by-Step Installation

### 1. Prerequisites

Install required software:

```bash
# Node.js 16+ (check version)
node --version

# PostgreSQL 12+ (check version)
psql --version

# If not installed:
# Ubuntu/Debian
sudo apt update
sudo apt install nodejs npm postgresql postgresql-contrib

# macOS (using Homebrew)
brew install node postgresql
brew services start postgresql

# Windows
# Download from https://nodejs.org and https://www.postgresql.org
```

### 2. Clone/Setup Project

```bash
cd /workspace
npm install
```

### 3. Configure Environment

```bash
# Copy example environment file
cp .env.example .env

# Edit .env with your settings
nano .env
```

**Required Configuration**:

```bash
# Database (PostgreSQL)
DB_HOST=localhost
DB_PORT=5432
DB_NAME=noryx_vpn
DB_USER=postgres
DB_PASSWORD=your_password

# RemnaWave API (Get from RemnaWave dashboard)
REMNAWAVE_API_URL=https://api.remnawave.com
REMNAWAVE_API_KEY=your_api_key_here
REMNAWAVE_API_SECRET=your_api_secret_here

# Security (Generate random string)
HMAC_SECRET=$(openssl rand -hex 32)

# Server
PORT=3000
NODE_ENV=development
```

### 4. Create Database

```bash
# Create PostgreSQL database
sudo -u postgres psql

# In PostgreSQL shell:
CREATE DATABASE noryx_vpn;
CREATE USER vpn_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE noryx_vpn TO vpn_user;
\q
```

### 5. Initialize Database Schema

```bash
npm run init-db
```

Expected output:
```
🔄 Initializing Noryx Premium VPN database...
✅ Database initialized successfully!
📊 Tables created:
   - users
   - subscriptions
   - vpn_configs
   - connection_logs
   - available_countries
```

### 6. Seed Demo Data (Optional)

```bash
npm run seed-demo
```

This creates:
- Demo user: `demo@noryx.com` / `demo123`
- Active subscription (30 days)

### 7. Start Server

```bash
# Development mode (auto-reload)
npm run dev

# Production mode
npm start
```

Expected output:
```
🚀 Noryx Premium VPN Server Started
📡 Listening on http://0.0.0.0:3000
🌍 Environment: development

📋 Available Endpoints:
   GET  /health
   POST /api/vpn/connect
   GET  /api/vpn/countries
   POST /api/vpn/change-country
   GET  /api/vpn/download/:token
```

### 8. Test the API

Open browser: `http://localhost:3000`

Or test with curl:

```bash
# Test health endpoint
curl http://localhost:3000/health

# Test smart connect
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"auto"}'

# Run all tests
npm run test-api
```

## Common Issues

### Issue 1: Database Connection Failed

**Error**: `Error: connect ECONNREFUSED 127.0.0.1:5432`

**Solution**:
```bash
# Check if PostgreSQL is running
sudo systemctl status postgresql

# Start PostgreSQL
sudo systemctl start postgresql

# Or on macOS
brew services start postgresql
```

### Issue 2: Permission Denied on Database

**Error**: `FATAL: role "postgres" does not exist`

**Solution**:
```bash
# Create postgres role
sudo -u postgres createuser -s $(whoami)

# Or set correct user in .env
DB_USER=your_actual_username
```

### Issue 3: Table Does Not Exist

**Error**: `relation "users" does not exist`

**Solution**:
```bash
# Re-run database initialization
npm run init-db
```

### Issue 4: Port Already in Use

**Error**: `Error: listen EADDRINUSE: address already in use :::3000`

**Solution**:
```bash
# Find process using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or change port in .env
PORT=3001
```

### Issue 5: RemnaWave API Errors

**Error**: `Failed to create VPN subscription`

**Solution**:
1. Verify API credentials in `.env`
2. Check RemnaWave API status
3. Review API documentation for changes
4. Check network connectivity

## Directory Structure

```
/workspace/
├── src/
│   ├── server.js              # Main Express server
│   ├── database/
│   │   ├── db.js             # Database connection pool
│   │   ├── init.js           # Database initialization
│   │   └── schema.sql        # Database schema
│   ├── routes/
│   │   └── vpn.js            # VPN endpoints
│   └── services/
│       ├── remnawave.js      # RemnaWave API client
│       ├── platformDetector.js # Platform detection
│       ├── tokenService.js   # HMAC token generation
│       └── qrService.js      # QR code generation
├── public/
│   └── index.html            # Frontend UI
├── scripts/
│   ├── seed-demo-data.js     # Demo data seeder
│   └── test-endpoints.sh     # API testing script
├── .env                      # Environment configuration (gitignored)
├── .env.example              # Example environment file
├── package.json              # Dependencies
└── README.md                 # Documentation
```

## Next Steps

1. **Add Authentication**: Implement JWT-based user authentication
2. **Create User Registration**: Build signup/login endpoints
3. **Add Payment Integration**: Integrate Stripe/PayPal for subscriptions
4. **Implement WebSocket**: Real-time connection status updates
5. **Build Admin Dashboard**: Server management and analytics
6. **Deploy to Production**: Use PM2, Docker, or cloud platforms

## Development Workflow

```bash
# 1. Make code changes
nano src/routes/vpn.js

# 2. Server auto-reloads (if using npm run dev)

# 3. Test changes
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"auto"}'

# 4. Check logs
# Server logs appear in terminal
```

## Production Deployment

### Using PM2 (Process Manager)

```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start src/server.js --name noryx-vpn

# Setup auto-restart on reboot
pm2 startup
pm2 save

# Monitor
pm2 monit

# View logs
pm2 logs noryx-vpn
```

### Using Docker

Create `Dockerfile`:
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
EXPOSE 3000
CMD ["node", "src/server.js"]
```

Build and run:
```bash
docker build -t noryx-vpn .
docker run -p 3000:3000 --env-file .env noryx-vpn
```

### Environment Variables for Production

```bash
NODE_ENV=production
PORT=3000
DB_HOST=your-production-db-host
REMNAWAVE_API_URL=https://api.remnawave.com
HMAC_SECRET=$(openssl rand -hex 32)
ALLOWED_ORIGINS=https://yourdomain.com
```

## Security Checklist

- [ ] Strong `HMAC_SECRET` generated
- [ ] PostgreSQL password is strong
- [ ] `.env` file is gitignored
- [ ] RemnaWave API credentials secured
- [ ] CORS configured for production domain
- [ ] Rate limiting enabled
- [ ] HTTPS/TLS configured
- [ ] Database backups scheduled
- [ ] Logs monitored for errors

## Support

For issues:
1. Check this guide
2. Review server logs
3. Test with demo data
4. Check RemnaWave API status
5. Open GitHub issue

Happy coding! 🚀
