# 🏗️ Noryx Premium VPN - System Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENT DEVICES                          │
├─────────────┬─────────────┬─────────────┬─────────────┬─────────┤
│     iOS     │   Android   │   Windows   │    macOS    │  Linux  │
│  (Safari)   │  (Chrome)   │   (Edge)    │  (Safari)   │ (Firefox│
└──────┬──────┴──────┬──────┴──────┬──────┴──────┬──────┴─────┬───┘
       │             │             │             │            │
       │             │             │             │            │
       ▼             ▼             ▼             ▼            ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BROWSER / WEB APP                          │
│                     (http://localhost:3000)                     │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  Smart Connect Button Logic (JavaScript)                  │ │
│  │  - Detects platform from User-Agent                       │ │
│  │  - Sends POST request to /api/vpn/connect                │ │
│  │  - Handles response (deep-link/file/QR)                   │ │
│  └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────┬───────────────────────────────────┘
                              │ HTTP POST
                              │ {userId, countryCode}
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     EXPRESS SERVER (Node.js)                    │
│                        Port: 3000                               │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │ Middleware Stack                                          │ │
│  │ - Helmet (Security headers)                               │ │
│  │ - CORS (Origin validation)                                │ │
│  │ - Rate Limiter (100 req/15min)                           │ │
│  │ - Body Parser (JSON/URL-encoded)                         │ │
│  └───────────────────────────────────────────────────────────┘ │
│                              │                                  │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │ Platform Detection Service                                │ │
│  │ - detectPlatform(userAgent)                               │ │
│  │ - getDeliveryFormat(platform)                             │ │
│  │ - getDeepLinkScheme(platform, protocol)                   │ │
│  └───────────────────────────────────────────────────────────┘ │
│                              │                                  │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │ Smart Routing Logic                                       │ │
│  │ - iOS/Android → Deep-link                                 │ │
│  │ - Desktop → Secure file download                          │ │
│  │ - Unknown → QR code                                       │ │
│  └───────────────────────────────────────────────────────────┘ │
│                              │                                  │
│             ┌────────────────┼────────────────┐                │
│             ▼                ▼                ▼                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │ Deep-Link    │  │ Token Gen    │  │ QR Generator │        │
│  │ Generator    │  │ Service      │  │ Service      │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
└─────┬────────────────────┬──────────────────────┬─────────────┘
      │                    │                      │
      │                    │                      │
      ▼                    ▼                      ▼
┌─────────────────┐  ┌──────────────────┐  ┌──────────────┐
│  PostgreSQL     │  │  RemnaWave API   │  │  qrcode lib  │
│  (Local DB)     │  │  (External)      │  │  (npm pkg)   │
├─────────────────┤  ├──────────────────┤  └──────────────┘
│ • users         │  │ POST /subs       │
│ • subscriptions │  │ GET /subs/:id    │
│ • vpn_configs   │  │ PATCH /subs/:id  │
│ • conn_logs     │  │ GET /locations   │
│ • countries     │  │ DELETE /subs/:id │
└─────────────────┘  └──────────────────┘
```

## Request Flow Diagram

### Flow 1: iOS User Connecting to VPN

```
┌─────────┐
│ iPhone  │ User clicks "Connect to VPN"
│ Safari  │
└────┬────┘
     │ POST /api/vpn/connect
     │ User-Agent: Mozilla/5.0 (iPhone...)
     │ Body: {userId: 1, countryCode: "us"}
     ▼
┌─────────────────────────────┐
│ Express Server              │
│ ┌─────────────────────────┐ │
│ │ 1. Platform Detection   │ │
│ │    detectPlatform()     │ │
│ │    → "ios"              │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 2. Subscription Check   │ │
│ │    SELECT FROM subs     │─┼──→ PostgreSQL
│ │    WHERE user_id = 1    │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 3. Provision VPN        │ │
│ │    if !exists:          │ │
│ │    createSubscription() │─┼──→ RemnaWave API
│ └─────────────────────────┘ │      POST /subscriptions
│ ┌─────────────────────────┐ │      {user_id, country}
│ │ 4. Generate Deep-Link   │ │
│ │    format = "deep-link" │ │      ← {subscription_id,
│ │    scheme = shadowrocket│ │         config_url,
│ └─────────────────────────┘ │         protocol}
│ ┌─────────────────────────┐ │
│ │ 5. Log Connection       │ │
│ │    INSERT INTO logs     │─┼──→ PostgreSQL
│ └─────────────────────────┘ │
└─────────────┬───────────────┘
              │
              │ Response:
              │ {
              │   platform: "ios",
              │   deliveryFormat: "deep-link",
              │   deepLink: "shadowrocket://add/ss://...",
              │   configUrl: "ss://...",
              │   serverLocation: "United States - New York"
              │ }
              ▼
         ┌─────────┐
         │ iPhone  │ JavaScript receives response
         │ Safari  │ → window.location.href = deepLink
         └────┬────┘ → Shadowrocket app opens
              │      → Config imported
              │      → User connects to VPN
              ▼
         [Connected to VPN]
```

### Flow 2: Windows User Downloading Config File

```
┌──────────┐
│ Windows  │ User clicks "Connect to VPN"
│  Chrome  │
└────┬─────┘
     │ POST /api/vpn/connect
     │ User-Agent: Mozilla/5.0 (Windows NT 10.0...)
     │ Body: {userId: 1, countryCode: "uk"}
     ▼
┌─────────────────────────────┐
│ Express Server              │
│ ┌─────────────────────────┐ │
│ │ 1. Platform Detection   │ │
│ │    detectPlatform()     │ │
│ │    → "windows"          │ │
│ │    format = "file"      │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 2. Generate HMAC Token  │ │
│ │    generateDownloadToken│ │
│ │    payload: userId:subId│ │
│ │    :expiresAt:hmac      │ │
│ │    → base64url encoded  │ │
│ └─────────────────────────┘ │
└─────────────┬───────────────┘
              │
              │ Response:
              │ {
              │   platform: "windows",
              │   deliveryFormat: "file",
              │   downloadUrl: "/api/vpn/download/abc123...",
              │   expiresIn: 300
              │ }
              ▼
         ┌──────────┐
         │ Windows  │ JavaScript receives response
         │  Chrome  │ → window.location.href = downloadUrl
         └────┬─────┘
              │ GET /api/vpn/download/abc123...
              ▼
┌─────────────────────────────┐
│ Express Server              │
│ ┌─────────────────────────┐ │
│ │ 1. Validate Token       │ │
│ │    validateDownloadToken│ │
│ │    - Decode base64url   │ │
│ │    - Check expiry       │ │
│ │    - Verify HMAC        │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 2. Fetch Config         │ │
│ │    getConfigFileContent │─┼──→ RemnaWave API
│ └─────────────────────────┘ │      GET /subs/:id/config-file
│ ┌─────────────────────────┐ │
│ │ 3. Send File            │ │      ← {config_content}
│ │    Content-Disposition  │ │
│ │    attachment; ...      │ │
│ └─────────────────────────┘ │
└─────────────┬───────────────┘
              │
              │ File download:
              │ noryx-vpn-config.conf
              ▼
         ┌──────────┐
         │ Windows  │ File saved to Downloads
         │  Chrome  │ → User imports to VPN client
         └──────────┘ → User connects to VPN
```

### Flow 3: Country Change

```
┌─────────┐
│  User   │ Selects "Germany" from dropdown
└────┬────┘
     │ POST /api/vpn/change-country
     │ Body: {userId: 1, countryCode: "de"}
     ▼
┌─────────────────────────────┐
│ Express Server              │
│ ┌─────────────────────────┐ │
│ │ 1. Get Current Config   │ │
│ │    SELECT remnawave_id  │─┼──→ PostgreSQL
│ │    FROM vpn_configs     │ │
│ │    WHERE user_id = 1    │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 2. Update RemnaWave     │ │
│ │    updateSubscription   │─┼──→ RemnaWave API
│ │    Country(id, "de")    │ │      PATCH /subs/:id
│ └─────────────────────────┘ │      {country: "de"}
│ ┌─────────────────────────┐ │
│ │ 3. Update Local DB      │ │      ← {config_url,
│ │    UPDATE vpn_configs   │─┼──→ PostgreSQL  server_location}
│ │    SET country = "de"   │ │
│ └─────────────────────────┘ │
└─────────────┬───────────────┘
              │
              │ Response:
              │ {
              │   success: true,
              │   countryCode: "de",
              │   serverLocation: "Germany - Frankfurt"
              │ }
              ▼
         ┌─────────┐
         │  User   │ UI updates to show new location
         └─────────┘
```

## Security Architecture

```
┌────────────────────────────────────────────────────────────┐
│                      Security Layers                       │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  1. NETWORK LAYER                                          │
│     ┌──────────────────────────────────────────────┐      │
│     │ • CORS (origin validation)                   │      │
│     │ • Rate Limiting (100 req/15min per IP)       │      │
│     │ • Helmet.js security headers                 │      │
│     └──────────────────────────────────────────────┘      │
│                                                            │
│  2. APPLICATION LAYER                                      │
│     ┌──────────────────────────────────────────────┐      │
│     │ • Input validation (userId, countryCode)     │      │
│     │ • SQL injection prevention (parameterized)   │      │
│     │ • Error message sanitization                 │      │
│     └──────────────────────────────────────────────┘      │
│                                                            │
│  3. AUTHENTICATION LAYER                                   │
│     ┌──────────────────────────────────────────────┐      │
│     │ • HMAC token generation                      │      │
│     │   - SHA-256 hash                             │      │
│     │   - Secret key from env                      │      │
│     │   - 5-minute expiry                          │      │
│     │ • Token validation                           │      │
│     │   - Signature verification                   │      │
│     │   - Expiry check                             │      │
│     └──────────────────────────────────────────────┘      │
│                                                            │
│  4. DATA LAYER                                             │
│     ┌──────────────────────────────────────────────┐      │
│     │ • Environment variables (.env)               │      │
│     │   - DB credentials                           │      │
│     │   - RemnaWave API keys (never exposed)       │      │
│     │   - HMAC secret                              │      │
│     │ • Database isolation                         │      │
│     │ • Connection pooling                         │      │
│     └──────────────────────────────────────────────┘      │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

## Token Flow (HMAC Authentication)

```
┌──────────────────────────────────────────────────────────────┐
│                  Token Generation                            │
└──────────────────────────────────────────────────────────────┘

Input:
  userId = 1
  subscriptionId = "sub_abc123"
  expiresAt = Date.now() + 300000 (5 min)

Step 1: Create Payload
  payload = "1:sub_abc123:1700000000"

Step 2: Generate HMAC
  hmac = HMAC-SHA256(payload, HMAC_SECRET)
  hmac = "a1b2c3d4e5f6..."

Step 3: Combine and Encode
  combined = "1:sub_abc123:1700000000:a1b2c3d4e5f6..."
  token = base64url(combined)
  token = "MXN1Yl9hYmMxMjM6MTcwMDAwMDAwMDphMWIyYzNkNGU1ZjYuLi4"

┌──────────────────────────────────────────────────────────────┐
│                  Token Validation                            │
└──────────────────────────────────────────────────────────────┘

Step 1: Decode Token
  decoded = base64url_decode(token)
  parts = decoded.split(':')
  [userId, subscriptionId, expiresAt, providedHmac] = parts

Step 2: Check Expiry
  if (Date.now() > expiresAt) → INVALID (expired)

Step 3: Verify HMAC
  payload = "1:sub_abc123:1700000000"
  expectedHmac = HMAC-SHA256(payload, HMAC_SECRET)

  if (expectedHmac !== providedHmac) → INVALID (tampered)

Step 4: Return Payload
  return {userId: 1, subscriptionId: "sub_abc123"}
```

## Database Schema Relationships

```
┌──────────────┐
│    users     │
│──────────────│
│ id (PK)      │◄─────┐
│ email        │      │
│ password_hash│      │
└──────────────┘      │
                      │
                      │ 1:N
                      │
              ┌───────┴────────┐
              │ subscriptions  │
              │────────────────│
              │ id (PK)        │◄─────┐
              │ user_id (FK)   │      │
              │ plan_type      │      │
              │ status         │      │
              │ expires_at     │      │
              └────────────────┘      │
                                      │ 1:1
                                      │
                              ┌───────┴────────┐
                              │  vpn_configs   │
                              │────────────────│
                              │ id (PK)        │
                              │ user_id (FK)   │
                              │ subscription_id│
                              │ remnawave_sub_id
                              │ country_code   │
                              │ server_location│
                              └────────────────┘

┌──────────────────┐
│ available_       │
│ countries        │
│──────────────────│
│ country_code (PK)│
│ country_name     │
│ flag_emoji       │
│ is_available     │
│ priority         │
└──────────────────┘

┌──────────────────┐
│ connection_      │
│ logs             │
│──────────────────│
│ id (PK)          │
│ user_id (FK)     │
│ platform         │
│ connection_type  │
│ country_code     │
│ connected_at     │
└──────────────────┘
```

## File Structure

```
noryx-premium-vpn/
│
├── src/
│   ├── server.js                 [Main Express server]
│   │   ├─ Middleware setup
│   │   ├─ Route registration
│   │   └─ Error handling
│   │
│   ├── database/
│   │   ├── db.js                 [Connection pool]
│   │   ├── init.js               [Schema initialization]
│   │   └── schema.sql            [Database schema]
│   │
│   ├── routes/
│   │   └── vpn.js                [VPN API endpoints]
│   │       ├─ POST /connect
│   │       ├─ GET /countries
│   │       ├─ POST /change-country
│   │       └─ GET /download/:token
│   │
│   └── services/
│       ├── remnawave.js          [RemnaWave API client]
│       │   ├─ createSubscription()
│       │   ├─ getSubscriptionConfig()
│       │   ├─ updateSubscriptionCountry()
│       │   └─ getConfigFileContent()
│       │
│       ├── platformDetector.js   [Platform detection]
│       │   ├─ detectPlatform()
│       │   ├─ getDeliveryFormat()
│       │   └─ getDeepLinkScheme()
│       │
│       ├── tokenService.js       [HMAC tokens]
│       │   ├─ generateDownloadToken()
│       │   └─ validateDownloadToken()
│       │
│       └── qrService.js          [QR code generation]
│           ├─ generateQRCode()
│           └─ generateQRCodeSVG()
│
├── public/
│   └── index.html                [Frontend UI]
│       ├─ Smart Connect Button
│       ├─ Country selection
│       └─ Response handling
│
├── scripts/
│   ├── seed-demo-data.js         [Demo data seeder]
│   └── test-endpoints.sh         [API testing]
│
├── .env                          [Environment config]
├── package.json                  [Dependencies]
└── README.md                     [Documentation]
```

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    PRODUCTION SETUP                     │
└─────────────────────────────────────────────────────────┘

                        ┌──────────────┐
                        │   Internet   │
                        └───────┬──────┘
                                │
                                ▼
                        ┌──────────────┐
                        │  CloudFlare  │ (SSL/CDN)
                        └───────┬──────┘
                                │
                                ▼
                        ┌──────────────┐
                        │  Load        │
                        │  Balancer    │
                        └───┬──────┬───┘
                            │      │
                 ┌──────────┘      └──────────┐
                 ▼                            ▼
        ┌─────────────────┐         ┌─────────────────┐
        │  Node.js        │         │  Node.js        │
        │  Instance 1     │         │  Instance 2     │
        │  (PM2)          │         │  (PM2)          │
        └────────┬────────┘         └────────┬────────┘
                 │                           │
                 └───────────┬───────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  PostgreSQL     │
                    │  (Master)       │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  PostgreSQL     │
                    │  (Replica)      │
                    └─────────────────┘

External Services:
    ┌──────────────────┐
    │  RemnaWave API   │ (VPN provisioning)
    └──────────────────┘
```

---

**Architecture Design Complete** ✨

This architecture supports:
- High availability (multiple instances)
- Horizontal scaling (add more Node.js instances)
- Database replication (read replicas)
- CDN acceleration (CloudFlare)
- SSL termination (CloudFlare)
- Load balancing (distribute traffic)
