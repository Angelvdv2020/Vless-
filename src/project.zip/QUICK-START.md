# ⚡ Quick Start Guide

Get Noryx Premium VPN running in 5 minutes!

## Prerequisites Checklist

- [ ] Node.js 16+ installed (`node --version`)
- [ ] PostgreSQL 12+ installed (`psql --version`)
- [ ] RemnaWave API credentials (API key & secret)

## 5-Minute Setup

### Step 1: Install Dependencies (30 seconds)
```bash
cd /workspace
npm install
```

### Step 2: Configure Environment (1 minute)
```bash
# Edit .env file
nano .env

# Required changes:
# 1. Set your PostgreSQL password
# 2. Add RemnaWave API credentials
# 3. Save and exit (Ctrl+X, Y, Enter)
```

### Step 3: Create Database (1 minute)
```bash
# Option A: Using psql
sudo -u postgres psql
CREATE DATABASE noryx_vpn;
\q

# Option B: Using createdb
createdb noryx_vpn
```

### Step 4: Initialize Schema (30 seconds)
```bash
npm run init-db
```

### Step 5: Seed Demo Data (30 seconds)
```bash
npm run seed-demo
```

### Step 6: Start Server (30 seconds)
```bash
npm run dev
```

## ✅ Verification

### Test 1: Health Check
```bash
curl http://localhost:3000/health
```

Expected output:
```json
{"status":"ok","service":"Noryx Premium VPN"}
```

### Test 2: Open Browser
```
http://localhost:3000
```

You should see the Noryx Premium VPN interface!

### Test 3: Test Smart Connect
```bash
curl -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"auto"}'
```

## 🎯 What You Have Now

✅ **Working VPN Service** with:
- Smart platform detection
- Country selection (8 locations)
- Deep-link support (iOS/Android)
- File download (Desktop)
- QR code fallback
- Secure token authentication
- Rate limiting
- Full API documentation

## 📝 Quick Reference

### Demo User Credentials
```
User ID: 1
Email: demo@noryx.com
Password: demo123
```

### API Endpoints
```
POST   /api/vpn/connect          # Smart Connect Button
GET    /api/vpn/countries        # Get available countries
POST   /api/vpn/change-country   # Switch server location
GET    /api/vpn/download/:token  # Download config file
```

### NPM Scripts
```bash
npm start       # Start production server
npm run dev     # Start development server (auto-reload)
npm run init-db # Initialize database schema
npm run seed-demo # Create demo user and subscription
npm run test-api  # Run API tests
```

## 🚨 Troubleshooting

### Issue: Database connection failed
**Solution:**
```bash
# Start PostgreSQL
sudo systemctl start postgresql

# Or on macOS
brew services start postgresql
```

### Issue: Port 3000 already in use
**Solution:**
```bash
# Kill process on port 3000
lsof -i :3000
kill -9 <PID>

# Or change port in .env
PORT=3001
```

### Issue: Table does not exist
**Solution:**
```bash
# Re-run initialization
npm run init-db
```

## 📚 Next Steps

1. **Customize Frontend**: Edit `public/index.html`
2. **Add Authentication**: Implement JWT auth
3. **Add Payments**: Integrate Stripe/PayPal
4. **Deploy**: Use PM2, Docker, or cloud platform
5. **Review Docs**: Read `README.md` for full features

## 🎉 Success!

Your VPN service is now running! Test it with different devices:

- **iOS**: Should get deep-link
- **Android**: Should get deep-link
- **Desktop**: Should get file download
- **Unknown**: Should get QR code

## 📞 Need Help?

1. Check `SETUP.md` for detailed setup
2. Review `API-EXAMPLES.md` for usage examples
3. Read `IMPLEMENTATION.md` for technical details
4. See `PROJECT-SUMMARY.md` for overview

---

**Time to production: ~5 minutes** ⚡

Ready to scale? Check deployment options in `README.md`!
