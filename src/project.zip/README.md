# Noryx Premium VPN - Smart Connect Button

A production-ready VPN service with intelligent platform detection and automatic configuration delivery.

## Features

### Smart Connect Button
- **Automatic Platform Detection**: Detects iOS, Android, Windows, macOS, Linux
- **Intelligent Delivery Formats**:
  - **iOS**: Deep-link for Shadowrocket/Quantumult
  - **Android**: Deep-link for V2RayNG/Clash
  - **Desktop**: Secure file download with HMAC tokens
  - **Fallback**: QR code for unknown platforms

### Location Selection
- **Multi-Country Support**: US, UK, Germany, Netherlands, Singapore, Japan, Canada
- **Auto Mode**: Automatically selects best server
- **On-Demand Switching**: Change location without reconnecting

### Security
- **No Credential Exposure**: RemnaWave API credentials never sent to client
- **PostgreSQL as Source of Truth**: All user data stored locally
- **HMAC Token Authentication**: Short-lived tokens (5 min) for file downloads
- **Rate Limiting**: Protection against API abuse
- **CORS Protection**: Configurable allowed origins

## Architecture

```
┌─────────────┐
│   Client    │
│  (Browser)  │
└──────┬──────┘
       │
       │ POST /api/vpn/connect
       │ {userId, countryCode}
       │
       ▼
┌─────────────────────────┐
│   Express Server        │
│   - Platform Detection  │
│   - Smart Routing       │
│   - Token Generation    │
└──────┬──────────────┬───┘
       │              │
       ▼              ▼
┌─────────────┐  ┌────────────┐
│ PostgreSQL  │  │ RemnaWave  │
│  (Local)    │  │    API     │
└─────────────┘  └────────────┘
```

## Installation

### Prerequisites
- Node.js 16+
- PostgreSQL 12+
- RemnaWave API credentials

### Setup

1. **Install dependencies**:
```bash
npm install
```

2. **Configure environment**:
```bash
cp .env.example .env
# Edit .env with your credentials
```

3. **Initialize database**:
```bash
npm run init-db
```

4. **Start server**:
```bash
npm start
# or for development
npm run dev
```

## API Documentation

### 1. Smart Connect

**Endpoint**: `POST /api/vpn/connect`

**Request**:
```json
{
  "userId": 1,
  "countryCode": "auto"
}
```

**Response (iOS/Android - Deep Link)**:
```json
{
  "platform": "ios",
  "deliveryFormat": "deep-link",
  "serverLocation": "United States",
  "countryCode": "us",
  "deepLink": "shadowrocket://add/ss://...",
  "configUrl": "https://api.remnawave.com/config/..."
}
```

**Response (Desktop - File Download)**:
```json
{
  "platform": "windows",
  "deliveryFormat": "file",
  "serverLocation": "United States",
  "countryCode": "us",
  "downloadUrl": "/api/vpn/download/abc123...",
  "expiresIn": 300
}
```

**Response (Unknown - QR Code)**:
```json
{
  "platform": "unknown",
  "deliveryFormat": "qr-code",
  "serverLocation": "United States",
  "countryCode": "us",
  "qrCode": "data:image/png;base64,...",
  "configUrl": "https://api.remnawave.com/config/..."
}
```

### 2. Get Available Countries

**Endpoint**: `GET /api/vpn/countries`

**Response**:
```json
{
  "countries": [
    {
      "country_code": "auto",
      "country_name": "Auto (Best)",
      "flag_emoji": "🌍",
      "is_available": true
    },
    {
      "country_code": "us",
      "country_name": "United States",
      "flag_emoji": "🇺🇸",
      "is_available": true
    }
  ]
}
```

### 3. Change Country

**Endpoint**: `POST /api/vpn/change-country`

**Request**:
```json
{
  "userId": 1,
  "countryCode": "uk"
}
```

**Response**:
```json
{
  "success": true,
  "countryCode": "uk",
  "serverLocation": "United Kingdom - London",
  "message": "VPN country changed to uk"
}
```

### 4. Download Config File

**Endpoint**: `GET /api/vpn/download/:token`

**Description**: Downloads configuration file using short-lived HMAC token.

**Response**: Configuration file (application/octet-stream)

## Database Schema

### Users
```sql
id SERIAL PRIMARY KEY
email VARCHAR(255) UNIQUE NOT NULL
password_hash VARCHAR(255) NOT NULL
created_at TIMESTAMP
updated_at TIMESTAMP
```

### Subscriptions
```sql
id SERIAL PRIMARY KEY
user_id INTEGER REFERENCES users(id)
plan_type VARCHAR(50) -- 'monthly', 'yearly', 'trial'
status VARCHAR(50) -- 'active', 'expired', 'cancelled'
started_at TIMESTAMP
expires_at TIMESTAMP
```

### VPN Configs
```sql
id SERIAL PRIMARY KEY
user_id INTEGER REFERENCES users(id)
subscription_id INTEGER REFERENCES subscriptions(id)
remnawave_subscription_id VARCHAR(255) UNIQUE
country_code VARCHAR(10)
server_location VARCHAR(100)
config_type VARCHAR(50)
created_at TIMESTAMP
updated_at TIMESTAMP
```

## Security Best Practices

1. **Environment Variables**: Never commit `.env` file
2. **HMAC Secret**: Generate strong random secret: `openssl rand -hex 32`
3. **Database Credentials**: Use strong passwords and restrict access
4. **RemnaWave API**: Store credentials server-side only
5. **Rate Limiting**: Adjust based on your traffic patterns
6. **CORS**: Configure allowed origins for production

## Deployment

### Environment Variables (Production)
```bash
NODE_ENV=production
PORT=3000
DB_HOST=your-db-host
DB_PORT=5432
DB_NAME=noryx_vpn
DB_USER=vpn_user
DB_PASSWORD=strong-password
REMNAWAVE_API_URL=https://api.remnawave.com
REMNAWAVE_API_KEY=your-api-key
REMNAWAVE_API_SECRET=your-api-secret
HMAC_SECRET=your-hmac-secret
TOKEN_EXPIRY_SECONDS=300
ALLOWED_ORIGINS=https://yourdomain.com
```

### PostgreSQL Setup
```bash
# Create database
createdb noryx_vpn

# Run migrations
npm run init-db
```

### Process Manager (PM2)
```bash
npm install -g pm2
pm2 start src/server.js --name noryx-vpn
pm2 save
pm2 startup
```

## Testing

### Manual Testing

1. **Test Platform Detection**:
```bash
# iOS
curl -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)" \
  -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"auto"}'

# Android
curl -H "User-Agent: Mozilla/5.0 (Linux; Android 10)" \
  -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"auto"}'

# Desktop
curl -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
  -X POST http://localhost:3000/api/vpn/connect \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"auto"}'
```

2. **Test Country Selection**:
```bash
curl -X GET http://localhost:3000/api/vpn/countries
```

3. **Test Country Change**:
```bash
curl -X POST http://localhost:3000/api/vpn/change-country \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"countryCode":"uk"}'
```

## Troubleshooting

### Database Connection Issues
- Verify PostgreSQL is running: `sudo systemctl status postgresql`
- Check credentials in `.env`
- Ensure database exists: `psql -l`

### RemnaWave API Errors
- Verify API credentials are correct
- Check API endpoint is accessible
- Review RemnaWave API documentation

### Token Validation Failures
- Check `HMAC_SECRET` is set correctly
- Verify token hasn't expired (default 5 minutes)
- Ensure token format is correct (base64url)

## License

MIT License

## Support

For issues and questions, please open an issue on GitHub.
