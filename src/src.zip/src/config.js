import dotenv from 'dotenv';
dotenv.config();

export const config = {
  port: parseInt(process.env.PORT) || 3100,
  host: process.env.HOST || '0.0.0.0',
  nodeEnv: process.env.NODE_ENV || 'development',

  ports: {
    website: parseInt(process.env.PORT) || 3100,
    remnawave: 3000,
    subscription: 3010,
  },

  supabase: {
    url: process.env.VITE_SUPABASE_URL || '',
    anonKey: process.env.VITE_SUPABASE_ANON_KEY || '',
  },

  security: {
    jwtSecret: process.env.JWT_SECRET || 'change-this-secret-key-in-production',
    jwtExpiry: process.env.JWT_EXPIRY || '24h',
    bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS) || 12,
  },

  remnawave: {
    baseUrl: process.env.REMNA_BASE_URL || 'http://127.0.0.1:3000',
    apiBaseUrl: process.env.REMNA_API_BASE_URL || 'https://panel.yourdomain.com/',
    authMode: process.env.REMNA_API_AUTH_MODE || 'basic',
    apiToken: process.env.REMNA_API_TOKEN || '',
    adminLogin: process.env.REMNA_ADMIN_LOGIN || '',
    adminPassword: process.env.REMNA_ADMIN_PASSWORD || '',
    timeout: 30000,
  },

  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    botUsername: process.env.TELEGRAM_BOT_USERNAME || '',
  },

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW) || 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
      return req.headers['x-forwarded-for']?.split(',')[0].trim() ||
             req.headers['x-real-ip'] ||
             req.ip ||
             req.socket.remoteAddress ||
             'unknown';
    },
  },

  cors: {
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true,
  },
};

if (config.nodeEnv === 'production') {
  if (!config.supabase.url || !config.supabase.anonKey) {
    console.error('ERROR: Supabase credentials missing in production!');
  }
  if (config.security.jwtSecret === 'change-this-secret-key-in-production') {
    console.error('ERROR: Change JWT_SECRET in production!');
  }
}
